import type { MouseEvent } from "react";
import { features } from "../data";
import SectionHead from "./SectionHead";

const statusLabel = {
  ready: { t: "آماده", c: "border-emerald-200 bg-emerald-50 text-emerald-700" },
  beta: { t: "بتا", c: "border-sky-200 bg-sky-50 text-sky-700" },
  soon: { t: "به‌زودی", c: "border-violet-200 bg-violet-50 text-violet-700" },
};

function spotlight(e: MouseEvent<HTMLDivElement>) {
  const el = e.currentTarget;
  const r = el.getBoundingClientRect();
  el.style.setProperty("--mx", `${e.clientX - r.left}px`);
  el.style.setProperty("--my", `${e.clientY - r.top}px`);
}

export default function Features() {
  return (
    <section id="features" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionHead
          badge="امکانات"
          title={
            <>
              هر چیزی که یک مطب مدرن
              <span className="text-gradient"> واقعاً </span>
              لازم دارد
            </>
          }
          sub="ماژول‌های CPMS مستقل اما یکپارچه‌اند؛ می‌توانید از نوبت‌دهی شروع کنید و به‌مرور پرونده بالینی، نسخه و مالی را فعال کنید."
        />

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => {
            const st = statusLabel[f.status];
            return (
              <div
                key={f.title}
                onMouseMove={spotlight}
                className="reveal group glass relative overflow-hidden rounded-3xl p-5 transition-all duration-500 hover:-translate-y-2 hover:shadow-xl"
                style={{ transitionDelay: `${(i % 3) * 90}ms` }}
              >
                <div
                  className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                  style={{
                    background:
                      "radial-gradient(260px circle at var(--mx) var(--my), rgba(16,185,129,0.12), transparent 65%)",
                  }}
                />
                <div className="relative">
                  <div className="flex items-start justify-between">
                    <span className="grid h-14 w-14 place-items-center rounded-2xl border border-gray-100 bg-gradient-to-br from-gray-50 to-white text-2xl shadow-sm transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6">
                      {f.icon}
                    </span>
                    <span className={`rounded-full border px-2.5 py-1 text-[10px] ${st.c}`}>{st.t}</span>
                  </div>

                  <h3 className="mt-5 text-lg font-extrabold text-gray-900">{f.title}</h3>
                  <p className="mt-2.5 text-[13px] leading-7 text-gray-500">{f.desc}</p>

                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {f.tags.map((t) => (
                      <span
                        key={t}
                        className="rounded-lg border border-gray-100 bg-gray-50 px-2 py-1 text-[10px] text-gray-400"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pointer-events-none absolute -bottom-24 -left-20 h-48 w-48 rounded-full bg-[radial-gradient(circle_at_center,rgba(110,231,183,0.16),transparent_68%)] transition-opacity duration-500 group-hover:opacity-90" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}