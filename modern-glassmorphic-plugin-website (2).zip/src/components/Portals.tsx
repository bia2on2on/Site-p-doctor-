import { useEffect, useState } from "react";
import { portals } from "../data";
import SectionHead from "./SectionHead";

export default function Portals() {
  const [active, setActive] = useState(0);
  const [auto, setAuto] = useState(true);

  useEffect(() => {
    if (!auto) return;
    const id = setInterval(() => setActive((a) => (a + 1) % portals.length), 5200);
    return () => clearInterval(id);
  }, [auto]);

  const p = portals[active];

  return (
    <section id="portals" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionHead
          badge="تجربه کاربری"
          title={
            <>
              چهار پرتال مستقل، برای
              <span className="text-gradient"> چهار نقش </span>
              متفاوت
            </>
          }
          sub="هر نقش فقط چیزی را می‌بیند که به آن نیاز دارد؛ مجوزدهی در سمت سرور و در مرز REST اعمال می‌شود، نه در رابط کاربری."
        />

        <div
          className="reveal mt-8 grid gap-6 lg:grid-cols-[320px_1fr]"
          onMouseEnter={() => setAuto(false)}
          onMouseLeave={() => setAuto(true)}
        >
          {/* tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0">
            {portals.map((item, i) => (
              <button
                key={item.key}
                onClick={() => setActive(i)}
                className={`group relative min-w-[190px] overflow-hidden rounded-2xl p-4 text-right transition-all duration-400 lg:min-w-0 ${
                  i === active ? "glass shadow-lg" : "glass-soft hover:shadow-md"
                }`}
              >
                {i === active && (
                  <span
                    className={`absolute inset-0 -z-10 bg-gradient-to-l ${item.accent} opacity-10`}
                  />
                )}
                <div className="flex items-center gap-3">
                  <span
                    className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl text-xl transition-transform duration-500 ${
                      i === active ? "scale-110 bg-white shadow-sm" : "bg-gray-50"
                    }`}
                  >
                    {item.icon}
                  </span>
                  <div>
                    <div className={`text-sm font-bold ${i === active ? "text-gray-900" : "text-gray-600"}`}>
                      {item.name}
                    </div>
                    <div className="mt-0.5 text-[10px] text-gray-400">{item.points.length} قابلیت کلیدی</div>
                  </div>
                </div>
                {i === active && (
                  <span className="absolute bottom-0 right-0 h-0.5 w-full origin-right bg-gradient-to-l from-emerald-400 to-sky-400" />
                )}
              </button>
            ))}
          </div>

          {/* panel */}
          <div key={p.key} className="glass relative overflow-hidden rounded-3xl p-6">
            <div
              className={`absolute -top-28 -left-20 h-72 w-72 rounded-full bg-gradient-to-br ${p.accent} opacity-25`}
              style={{
                maskImage: "radial-gradient(circle at center, #000 0%, transparent 70%)",
                WebkitMaskImage: "radial-gradient(circle at center, #000 0%, transparent 70%)",
              }}
            />
            <div className="relative grid gap-8 md:grid-cols-[1.1fr_0.9fr]">
              <div>
                <div className="text-4xl">{p.icon}</div>
                <h3 className="mt-4 text-2xl font-black text-gray-900">{p.headline}</h3>
                <p className="mt-1.5 text-xs text-gray-400">{p.name}</p>
                <ul className="mt-6 space-y-3">
                  {p.points.map((pt, i) => (
                    <li
                      key={pt}
                      className="reveal in flex items-start gap-3 text-[13px] leading-7 text-gray-600"
                      style={{ transitionDelay: `${i * 70}ms` }}
                    >
                      <span className="mt-1.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border border-emerald-200 bg-emerald-50 text-[10px] text-emerald-600">
                        ✓
                      </span>
                      {pt}
                    </li>
                  ))}
                </ul>
              </div>

              {/* mini device */}
              <div className="relative">
                <div className="glass-soft mx-auto w-full max-w-[260px] rounded-[26px] p-3">
                  <div className="mx-auto mb-3 h-1 w-14 rounded-full bg-gray-200" />
                  <div className="space-y-2.5">
                    <div className="rounded-2xl bg-gradient-to-l from-gray-100 to-gray-50 p-3">
                      <div className="text-[10px] text-gray-400">{p.name}</div>
                      <div className="mt-1 text-sm font-bold text-gray-800">خوش آمدید 👋</div>
                    </div>
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="animate-floaty rounded-2xl border border-gray-100 bg-white p-3 shadow-sm"
                        style={{ animationDelay: `${i * 0.6}s`, animationDuration: "6s" }}
                      >
                        <div className="h-1.5 w-2/3 rounded-full bg-gray-200" />
                        <div className="mt-2 h-1.5 w-1/3 rounded-full bg-emerald-200" />
                        <div className="mt-3 flex gap-1.5">
                          <span className="h-5 flex-1 rounded-md bg-gray-100" />
                          <span className="h-5 w-12 rounded-md bg-gradient-to-l from-emerald-200 to-sky-200" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}