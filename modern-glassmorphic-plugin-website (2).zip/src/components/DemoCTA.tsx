import { useState } from "react";
import type { FormEvent } from "react";

export default function DemoCTA() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", clinic: "", type: "مطب تک‌پزشک" });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  const field =
    "w-full rounded-2xl border border-gray-200 bg-white px-4 py-3 text-[13px] text-gray-800 placeholder:text-gray-300 outline-none transition focus:border-emerald-400 focus:shadow-md focus:shadow-emerald-500/10";

  return (
    <section id="demo" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <div className="reveal glass relative overflow-hidden rounded-[32px] p-8 sm:p-12">
          <div className="animate-aurora absolute -top-32 -left-24 h-80 w-80 rounded-full bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.30),transparent_66%)]" />
          <div
            className="animate-aurora absolute -bottom-32 -right-16 h-80 w-80 rounded-full bg-[radial-gradient(circle_at_center,rgba(56,163,244,0.28),transparent_66%)]"
            style={{ animationDelay: "-8s" }}
          />

          <div className="relative grid gap-10 lg:grid-cols-[1fr_1fr]">
            <div>
              <span className="glass-soft inline-flex rounded-full px-3.5 py-1.5 text-[11px] text-emerald-700">
                دموی اختصاصی
              </span>
              <h2 className="mt-5 text-3xl leading-[1.35] font-black text-gray-900 sm:text-4xl">
                مطب‌تان را
                <span className="text-gradient"> ۳۰ دقیقه‌ای </span>
                ببینید
              </h2>
              <p className="mt-4 max-w-md text-[14px] leading-8 text-gray-500">
                فرم زیر را پر کنید تا یک جلسه دموی رایگان برگزار کنیم. در این جلسه
                همه امکانات را با داده‌های واقعی مطب خودتان می‌بینید.
              </p>

              <ul className="mt-7 space-y-3">
                {[
                  "نصب روی هاست خودتان — اطلاعات نزد شما می‌ماند",
                  "راه‌اندازی اولیه کمتر از یک روز کاری",
                  "آموزش کامل منشی و پزشک به‌صورت آنلاین",
                ].map((t) => (
                  <li key={t} className="flex items-center gap-3 text-[13px] text-gray-600">
                    <span className="grid h-6 w-6 place-items-center rounded-lg bg-emerald-50 text-[11px] text-emerald-600">
                      ✓
                    </span>
                    {t}
                  </li>
                ))}
              </ul>
            </div>

            {sent ? (
              <div className="glass-soft flex flex-col items-center justify-center rounded-3xl p-10 text-center">
                <div className="animate-floaty text-5xl">✅</div>
                <h3 className="mt-5 text-xl font-black text-gray-900">درخواست شما ثبت شد</h3>
                <p className="mt-2 text-[13px] leading-7 text-gray-500">
                  همکاران ما در اولین فرصت کاری با شما تماس می‌گیرند تا زمان دمو را هماهنگ کنند.
                </p>
                <button
                  onClick={() => setSent(false)}
                  className="mt-6 rounded-xl border border-gray-200 bg-white px-5 py-2.5 text-xs text-gray-600 transition hover:bg-gray-50"
                >
                  ثبت درخواست دیگر
                </button>
              </div>
            ) : (
              <form onSubmit={submit} className="glass-soft space-y-3 rounded-3xl p-6 sm:p-7">
                <div className="grid gap-3 sm:grid-cols-2">
                  <input
                    required
                    placeholder="نام و نام خانوادگی"
                    className={field}
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                  <input
                    required
                    inputMode="tel"
                    placeholder="شماره موبایل"
                    className={field}
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
                <input
                  placeholder="نام مطب یا درمانگاه"
                  className={field}
                  value={form.clinic}
                  onChange={(e) => setForm({ ...form, clinic: e.target.value })}
                />
                <select
                  className={`${field} appearance-none`}
                  value={form.type}
                  onChange={(e) => setForm({ ...form, type: e.target.value })}
                >
                  {["مطب تک‌پزشک", "درمانگاه چندپزشکه", "چند شعبه یا سازمانی"].map((o) => (
                    <option key={o} className="bg-white">
                      {o}
                    </option>
                  ))}
                </select>
                <textarea
                  rows={3}
                  placeholder="توضیح کوتاه درباره نیاز شما (اختیاری)"
                  className={`${field} resize-none`}
                />
                <button
                  type="submit"
                  className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-l from-mint-400 to-azure-500 py-3.5 text-sm font-extrabold text-white transition hover:scale-[1.01]"
                >
                  <span className="relative z-10">ارسال درخواست دمو</span>
                  <span className="shine absolute inset-0 opacity-40" />
                </button>
                <p className="text-center text-[10px] text-gray-300">
                  اطلاعات شما فقط برای هماهنگی دمو استفاده می‌شود.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}