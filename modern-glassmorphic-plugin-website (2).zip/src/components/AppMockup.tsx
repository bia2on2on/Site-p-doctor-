const queue = [
  { n: "زهرا موسوی", t: "۰۹:۳۰", s: "در حال ویزیت", c: "mint" },
  { n: "امیر رضایی", t: "۰۹:۴۵", s: "در صف", c: "azure" },
  { n: "سارا کریمی", t: "۱۰:۰۰", s: "پذیرش شد", c: "violet" },
  { n: "محمد نوری", t: "۱۰:۱۵", s: "رزرو آنلاین", c: "slate" },
];

const tone: Record<string, string> = {
  mint: "bg-emerald-50 text-emerald-700 border-emerald-200",
  azure: "bg-sky-50 text-sky-700 border-sky-200",
  violet: "bg-violet-50 text-violet-700 border-violet-200",
  slate: "bg-gray-100 text-gray-600 border-gray-200",
};

function Bar({ h, delay }: { h: number; delay: string }) {
  return (
    <div className="flex h-24 w-full items-end">
      <div
        className="animate-floaty w-full rounded-t-md bg-gradient-to-t from-sky-500/50 to-emerald-400/90"
        style={{ height: `${h}%`, animationDelay: delay, animationDuration: "5s" }}
      />
    </div>
  );
}

export default function AppMockup() {
  return (
    <div className="relative rounded-[26px] border border-white bg-white/92 p-3 shadow-[0_18px_50px_-16px_rgba(26,31,54,0.22)] sm:p-4">
      {/* window chrome */}
      <div className="mb-3 flex items-center justify-between px-2">
        <div className="flex gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
        </div>
        <div className="rounded-md bg-gray-100 px-3 py-1 text-[10px] text-gray-400">
          سامانه مدیریت مطب
        </div>
        <div className="h-2.5 w-10" />
      </div>

      <div className="grid grid-cols-12 gap-3">
        {/* sidebar */}
        <aside className="col-span-3 hidden flex-col gap-2 rounded-2xl bg-gray-50 p-3 sm:flex">
          {[
            ["🏠", "داشبورد"],
            ["🗓️", "نوبت‌ها"],
            ["🎫", "صف پذیرش"],
            ["🩺", "ویزیت‌ها"],
            ["💊", "نسخه‌ها"],
            ["💳", "مالی"],
          ].map(([i, t], idx) => (
            <div
              key={t}
              className={`flex items-center gap-2 rounded-xl px-2.5 py-2 text-[11px] transition ${
                idx === 2
                  ? "bg-gradient-to-l from-emerald-100 to-sky-50 font-bold text-emerald-800"
                  : "text-gray-500"
              }`}
            >
              <span>{i}</span>
              <span>{t}</span>
            </div>
          ))}
        </aside>

        {/* main */}
        <div className="col-span-12 space-y-3 sm:col-span-9">
          <div className="grid grid-cols-3 gap-2.5">
            {[
              ["ویزیت امروز", "۳۸", "+۱۲٪", "text-emerald-600"],
              ["بیمار در صف", "۶", "میانگین ۸ دقیقه", "text-sky-600"],
              ["درآمد امروز", "۲۴٫۵ م", "+۸٪", "text-violet-600"],
            ].map(([t, v, s, c]) => (
              <div key={t} className="rounded-2xl border border-gray-100 bg-white p-3 shadow-sm">
                <div className="text-[10px] text-gray-400">{t}</div>
                <div className="mt-1 text-lg font-extrabold text-gray-900">{v}</div>
                <div className={`text-[9px] ${c}`}>{s}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-5 gap-3">
            <div className="col-span-5 rounded-2xl border border-gray-100 bg-white p-3 shadow-sm lg:col-span-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[11px] font-bold text-gray-700">صف انتظار — شنبه ۱۴ تیر</span>
                <span className="rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[9px] text-emerald-700">
                  زنده
                </span>
              </div>
              <ul className="space-y-1.5">
                {queue.map((q, i) => (
                  <li
                    key={q.n}
                    className="flex items-center justify-between rounded-xl bg-gray-50 px-2.5 py-2 transition hover:bg-gray-100"
                    style={{ animation: `floaty 6s ease-in-out ${i * 0.4}s infinite` }}
                  >
                    <div className="flex items-center gap-2">
                      <span className="grid h-6 w-6 place-items-center rounded-lg bg-gradient-to-br from-sky-100 to-emerald-100 text-[9px] font-bold text-gray-700">
                        {q.n.charAt(0)}
                      </span>
                      <span className="text-[11px] text-gray-800">{q.n}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gray-400">{q.t}</span>
                      <span className={`rounded-full border px-2 py-0.5 text-[9px] ${tone[q.c]}`}>{q.s}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="col-span-5 rounded-2xl border border-gray-100 bg-white p-3 shadow-sm lg:col-span-2">
              <div className="mb-2 text-[11px] font-bold text-gray-700">مراجعات هفته</div>
              <div className="flex items-end gap-1.5">
                {[52, 74, 38, 90, 66, 81, 45].map((h, i) => (
                  <Bar key={i} h={h} delay={`${i * 0.25}s`} />
                ))}
              </div>
              <div className="mt-2 flex justify-between text-[8px] text-gray-300">
                {["ش", "ی", "د", "س", "چ", "پ", "ج"].map((d) => (
                  <span key={d}>{d}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}