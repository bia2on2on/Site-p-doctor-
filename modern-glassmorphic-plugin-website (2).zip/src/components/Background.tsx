export default function Background() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* base */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#f0f4fa] via-[#f7f9fd] to-[#eef3fa]" />

      {/* aurora glows — radial gradients are already soft, so no filter/blur needed */}
      <div className="animate-aurora absolute -top-48 right-[-10%] h-[50rem] w-[50rem] rounded-full bg-[radial-gradient(circle_at_center,rgba(16,184,148,0.20),transparent_62%)]" />
      <div
        className="animate-aurora absolute top-[18%] left-[-14%] h-[46rem] w-[46rem] rounded-full bg-[radial-gradient(circle_at_center,rgba(31,125,240,0.16),transparent_62%)]"
        style={{ animationDelay: "-6s" }}
      />
      <div
        className="animate-aurora absolute bottom-[-12%] right-[18%] h-[42rem] w-[42rem] rounded-full bg-[radial-gradient(circle_at_center,rgba(139,108,238,0.13),transparent_62%)]"
        style={{ animationDelay: "-12s" }}
      />

      {/* grid */}
      <div className="grid-bg absolute inset-0 opacity-80" />

      {/* vignette + noise */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,rgba(240,244,250,0.7)_100%)]" />
      <div className="noise absolute inset-0 opacity-[0.025]" />
    </div>
  );
}
