import { useEffect, useRef, useState } from "react";
import { prefersReducedMotion } from "../hooks/useReveal";

const R = 26;
const C = 2 * Math.PI * R;

export default function BackToTop() {
  const ringRef = useRef<SVGCircleElement>(null);
  const [visible, setVisible] = useState(false);

  // Scroll progress is written straight to the SVG — no React work per frame.
  useEffect(() => {
    let ticking = false;
    const update = () => {
      ticking = false;
      const el = document.documentElement;
      const max = el.scrollHeight - el.clientHeight;
      const p = max > 0 ? Math.min(1, Math.max(0, el.scrollTop / max)) : 0;
      setVisible(el.scrollTop > 380);
      if (ringRef.current) {
        ringRef.current.style.strokeDashoffset = String(C * (1 - p));
      }
    };
    const onScroll = () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(update);
      }
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const scrollTop = () => {
    window.scrollTo({ top: 0, behavior: prefersReducedMotion() ? "auto" : "smooth" });
  };

  return (
    <button
      type="button"
      onClick={scrollTop}
      tabIndex={visible ? 0 : -1}
      aria-label="بازگشت به بالای صفحه"
      className={`group fixed bottom-6 left-5 z-50 grid h-14 w-14 place-items-center rounded-full border border-white bg-white/95 shadow-[0_14px_36px_-10px_rgba(16,185,129,0.55)] transition-all duration-500 hover:border-emerald-200 hover:shadow-[0_20px_46px_-12px_rgba(16,185,129,0.75)] active:scale-95 ${
        visible
          ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
          : "pointer-events-none translate-y-5 scale-90 opacity-0"
      }`}
    >
      {/* soft halo */}
      <span className="pointer-events-none absolute inset-0 rounded-full bg-gradient-to-t from-emerald-100/70 to-transparent" />

      {/* scroll progress ring */}
      <svg className="pointer-events-none absolute inset-0 -rotate-90" viewBox="0 0 60 60" aria-hidden>
        <circle cx="30" cy="30" r={R} fill="none" stroke="#e3eaf4" strokeWidth="3" />
        <circle
          ref={ringRef}
          cx="30"
          cy="30"
          r={R}
          fill="none"
          stroke="url(#btnRing)"
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C}
          style={{ transition: "stroke-dashoffset 120ms linear" }}
        />
        <defs>
          <linearGradient id="btnRing" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#1f7df0" />
          </linearGradient>
        </defs>
      </svg>

      <svg
        width="21"
        height="21"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="relative text-emerald-600 transition-transform duration-300 group-hover:-translate-y-1"
        aria-hidden
      >
        <path d="M12 19V5M5 12l7-7 7 7" />
      </svg>

      {/* tooltip */}
      <span className="pointer-events-none absolute left-full ml-3 whitespace-nowrap rounded-xl border border-gray-100 bg-white px-3 py-1.5 text-xs text-gray-700 opacity-0 shadow-lg transition-opacity duration-300 group-hover:opacity-100">
        بازگشت به بالا
      </span>
    </button>
  );
}
