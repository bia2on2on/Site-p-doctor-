import SectionHead from "./SectionHead";

const chain = [
  { t: "سازمان", f: "سازمان", d: "مالک مجموعه" },
  { t: "کلینیک", f: "کلینیک", d: "هر مرکز درمانی" },
  { t: "شعبه", f: "شعبه", d: "مکان و ساعت کاری" },
  { t: "پزشک", f: "پزشک", d: "عضو چند مرکز" },
  { t: "کاربر", f: "کاربر", d: "دسترسی مشخص" },
];

const specs = [
  {
    icon: "🧱",
    title: "ساختار حرفه‌ای",
    desc: "کد سامانه به‌صورت ماژول‌های مستقل نوشته شده و هر بخش (پذیرش، مالی، نسخه) مسئول کار خودش است. ارتقا و توسعه بدون اختلال در کار روزانه انجام می‌شود.",
  },
  {
    icon: "🔌",
    title: "ارتباط امن و یکپارچه",
    desc: "تمام بخش‌های سامانه از طریق مسیرهای استاندارد با هم صحبت می‌کنند. هر کاربر فقط به بخش‌هایی که اجازه دارد دسترسی دارد.",
  },
  {
    icon: "🧪",
    title: "تست خودکار قبل از هر به‌روزرسانی",
    desc: "پیش از انتشار هر نسخه جدید، صدها تست خودکار روی سامانه اجرا می‌شود تا مطمئن باشیم چیزی خراب نمی‌شود.",
  },
  {
    icon: "🗃️",
    title: "به‌روزرسانی بدون از دست رفتن داده",
    desc: "به‌روزرسانی‌های سامانه به‌صورت مرحله‌ای و ایمن انجام می‌شود؛ اطلاعات بیماران، نسخه‌ها و مالی شما حفظ می‌شود.",
  },
  {
    icon: "⏱️",
    title: "تاریخ شمسی در همه جا",
    desc: "تمام تاریخ‌ها به‌صورت شمسی و اعداد به‌صورت فارسی نمایش داده می‌شوند. هر شعبه منطقه زمانی مستقل خودش را دارد.",
  },
  {
    icon: "⚡",
    title: "سرعت بالا حتی در ساعات شلوغ",
    desc: "سامانه برای مطب‌های پرمراجعه طراحی شده و حتی در شلوغ‌ترین ساعات بدون کندی کار می‌کند.",
  },
];

export default function Architecture() {
  return (
    <section id="architecture" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionHead
          badge="زیر کاپوت"
          title={
            <>
              ساختار حرفه‌ای، برای
              <span className="text-gradient"> اعتماد بلندمدت</span>
            </>
          }
          sub="این سامانه صرفاً یک نرم‌افزار ساده نیست؛ روی اصول مهندسی نرم‌افزار ساخته شده تا سال‌ها بدون دردسر کار کند."
        />

        {/* chain diagram */}
        <div className="reveal glass mt-8 overflow-hidden rounded-3xl p-6 sm:p-9">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-gray-700">ساختار سلسله‌مراتبی سامانه</h3>
            <span className="rounded-full border border-gray-100 bg-gray-50 px-3 py-1 text-[10px] text-gray-400">
              سازمان → کلینیک → شعبه → پزشک → کاربر
            </span>
          </div>

          <div className="relative grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
            <svg className="pointer-events-none absolute inset-0 hidden h-full w-full lg:block" aria-hidden>
              <line
                x1="2%" y1="50%" x2="98%" y2="50%"
                stroke="url(#chainGrad)" strokeWidth="2" className="animate-dash"
              />
              <defs>
                <linearGradient id="chainGrad" x1="0" x2="1">
                  <stop offset="0%" stopColor="#059669" />
                  <stop offset="100%" stopColor="#8b6cee" />
                </linearGradient>
              </defs>
            </svg>

            {chain.map((c, i) => (
              <div
                key={c.t}
                className="group relative rounded-2xl border border-gray-100 bg-white p-4 text-center shadow-sm transition hover:-translate-y-1.5 hover:shadow-lg"
                style={{ animation: `floaty ${6 + i}s ease-in-out ${i * 0.3}s infinite` }}
              >
                <div className="mx-auto mb-2 grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-emerald-100 to-sky-100 text-xs font-black text-emerald-700">
                  {i + 1}
                </div>
                <div className="text-[13px] font-extrabold text-gray-900">{c.f}</div>
                <div className="text-[10px] text-gray-400">{c.d}</div>
              </div>
            ))}
          </div>
        </div>

        {/* specs */}
        <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {specs.map((s, i) => (
            <div
              key={s.title}
              className="reveal glass-soft group rounded-3xl p-6 transition duration-500 hover:-translate-y-1.5 hover:shadow-lg"
              style={{ transitionDelay: `${(i % 3) * 80}ms` }}
            >
              <div className="flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-gray-50 text-xl transition group-hover:scale-110">
                  {s.icon}
                </span>
                <h4 className="text-[15px] font-bold text-gray-900">{s.title}</h4>
              </div>
              <p className="mt-3 text-[12.5px] leading-7 text-gray-500">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}