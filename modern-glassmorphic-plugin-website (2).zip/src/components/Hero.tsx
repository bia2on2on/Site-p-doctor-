import AppMockup from "./AppMockup";
import { stats } from "../data";

export default function Hero() {
  return (
    <section id="top" className="relative px-4 pt-24 pb-10 sm:px-8 sm:pt-28">
      <div className="mx-auto grid max-w-7xl items-center gap-8 lg:grid-cols-[1.05fr_1.25fr]">
        {/* copy */}
        <div className="reveal">
          <div className="glass-soft inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[12px] text-gray-600">
            <span className="relative flex h-2 w-2">
              <span
                className="absolute inline-flex h-full w-full rounded-full bg-emerald-400"
                style={{ animation: "pulseRing 1.8s ease-out infinite" }}
              />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
            </span>
            سامانه مدیریت مطب، آماده استفاده
          </div>

          <h1 className="mt-6 text-4xl leading-[1.25] font-black tracking-tight text-gray-900 sm:text-5xl lg:text-[3.4rem] lg:leading-[1.2]">
            مطبِ شما،
            <span className="text-gradient"> یکپارچه </span>
            در یک سامانه
          </h1>

          <p className="mt-5 max-w-xl text-[15px] leading-8 text-gray-600 sm:text-base">
            سامانه‌ای فارسی و راست‌چین برای مدیریت کامل مطب و درمانگاه. از
            <b className="text-gray-900"> نوبت‌دهی آنلاین </b>
            و
            <b className="text-gray-900"> پذیرش </b>
            تا
            <b className="text-gray-900"> پرونده بیمار، نسخه و امور مالی </b>
            — همه در یک جا، ساده و مطمئن.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href="#demo"
              className="group relative overflow-hidden rounded-2xl bg-gradient-to-l from-mint-400 via-mint-400 to-azure-500 px-6 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-emerald-500/25 transition hover:scale-[1.03]"
            >
              <span className="relative z-10">درخواست دموی رایگان</span>
              <span className="shine absolute inset-0 opacity-40" />
            </a>
            <a
              href="#features"
              className="glass rounded-2xl px-6 py-3.5 text-sm font-bold text-gray-700 transition hover:bg-white hover:shadow-md"
            >
              مشاهده امکانات ↙
            </a>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {stats.map((s, i) => (
              <div
                key={s.label}
                className="glass-soft rounded-2xl px-3 py-3 text-center transition hover:-translate-y-1 hover:shadow-md"
                style={{ transitionDelay: `${i * 40}ms` }}
              >
                <div className="text-xl font-black text-gradient">{s.value}</div>
                <div className="mt-0.5 text-[11px] text-gray-600">{s.label}</div>
                <div className="text-[9px] text-gray-400">{s.sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* mockup */}
        <div className="reveal relative" style={{ transitionDelay: "140ms" }}>
          <div className="absolute -inset-8 -z-10 rounded-[48px] bg-[radial-gradient(ellipse_at_center,rgba(110,231,183,0.32),rgba(125,211,252,0.18)_55%,transparent_78%)]" />
          <div className="animate-floaty-slow">
            <AppMockup />
          </div>

          {/* floating chips */}
          <div className="animate-floaty glass absolute -top-6 right-2 hidden rounded-2xl px-4 py-3 sm:block">
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-xl bg-emerald-100 text-base">💬</span>
              <div>
                <div className="text-[11px] font-bold text-gray-800">پیامک یادآوری ارسال شد</div>
                <div className="text-[9px] text-gray-400">چند لحظه پیش — ۱۲ بیمار</div>
              </div>
            </div>
          </div>

          <div
            className="animate-floaty glass absolute -bottom-7 left-0 hidden rounded-2xl px-4 py-3 sm:block"
            style={{ animationDelay: "-3s" }}
          >
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-xl bg-sky-100 text-base">🧾</span>
              <div>
                <div className="text-[11px] font-bold text-gray-800">نسخه صادر و چاپ شد</div>
                <div className="text-[9px] text-gray-400">دکتر احمدی — پنل پزشک</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* chips strip */}
      <div className="relative mx-auto mt-20 max-w-7xl">
        <div className="flex flex-wrap items-center justify-center gap-2.5">
          {[
            "بدون نیاز به تغییر هاست",
            "نصب روی سایت فعلی شما",
            "فارسی و راست‌چین",
            "تاریخ شمسی و اعداد فارسی",
            "پشتیبان‌گیری خودکار",
            "چاپ نسخه و رسید",
            "چند شعبه و چند تخصص",
          ].map((t) => (
            <span
              key={t}
              className="glass-soft rounded-full px-4 py-2 text-xs text-gray-500"
            >
              {t}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}