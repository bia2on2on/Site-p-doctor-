import Logo from "./Logo";

const cols = [
  {
    title: "محصول",
    links: [
      ["امکانات", "#features"],
      ["پنل‌ها", "#portals"],
      ["جریان کار", "#workflow"],
      ["موارد استفاده", "#scenarios"],
    ],
  },
  {
    title: "اطلاعات بیشتر",
    links: [
      ["پشتیبان‌گیری اطلاعات", "#backups"],
      ["ساختار سامانه", "#architecture"],
      ["مقایسه با روش‌های دیگر", "#compare"],
      ["سوالات متداول", "#faq"],
    ],
  },
  {
    title: "تماس",
    links: [
      ["درخواست دمو", "#demo"],
      ["مشاوره رایگان", "#demo"],
    ],
  },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-gray-100 px-4 pt-16 pb-8 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <Logo size={40} />
              <div>
                <div className="text-lg font-extrabold text-gray-900">سامانه مطب</div>
                <div className="text-[11px] text-gray-400">مدیریت هوشمند مطب و درمانگاه</div>
              </div>
            </div>
            <p className="mt-5 max-w-sm text-[12.5px] leading-7 text-gray-500">
              سامانه‌ای فارسی و راست‌چین برای مدیریت کامل مطب — از نوبت‌دهی آنلاین تا پرونده بیمار،
              نسخه و امور مالی، در یک جا.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {["فارسی و راست‌چین", "تاریخ شمسی", "پشتیبان‌گیری خودکار"].map((t) => (
                <span
                  key={t}
                  className="rounded-lg border border-gray-100 bg-gray-50 px-2.5 py-1 text-[10px] text-gray-400"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          {cols.map((c) => (
            <div key={c.title}>
              <h4 className="text-[13px] font-bold text-gray-700">{c.title}</h4>
              <ul className="mt-4 space-y-2.5">
                {c.links.map(([label, href]) => (
                  <li key={label}>
                    <a
                      href={href}
                      className="group inline-flex items-center gap-1.5 text-[12.5px] text-gray-500 transition hover:text-emerald-600"
                    >
                      <span className="h-px w-0 bg-emerald-400 transition-all duration-300 group-hover:w-3" />
                      {label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-gray-100 pt-6 sm:flex-row">
          <p className="text-[11px] text-gray-300">
            © {new Date().toLocaleDateString("fa-IR", { year: "numeric" })} — سامانه مطب. تمامی حقوق محفوظ است.
          </p>
          <div className="flex items-center gap-2 text-[11px] text-gray-300">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            آماده ارائه خدمات به مطب‌ها و درمانگاه‌ها
          </div>
        </div>
      </div>
    </footer>
  );
}