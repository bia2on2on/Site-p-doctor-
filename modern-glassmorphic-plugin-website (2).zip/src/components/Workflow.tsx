import SectionHead from "./SectionHead";

const steps = [
  {
    n: "۰۱",
    t: "رزرو نوبت توسط بیمار",
    d: "بیمار وارد سایت شما می‌شود، مطب و پزشک و ساعت دلخواهش را انتخاب می‌کند و نوبتش در کمتر از یک دقیقه ثبت می‌شود.",
    icon: "📱",
  },
  {
    n: "۰۲",
    t: "پذیرش و ورود به صف",
    d: "منشی نوبت آنلاین را به ویزیت تبدیل می‌کند. بیمار در صف قرار می‌گیرد و وضعیتش برای پزشک قابل مشاهده است.",
    icon: "🎫",
  },
  {
    n: "۰۳",
    t: "ویزیت و صدور نسخه",
    d: "پزشک یادداشت بالینی را ثبت می‌کند، نسخه را می‌نویسد، نهایی می‌کند و در صورت نیاز چاپ می‌کند.",
    icon: "🩺",
  },
  {
    n: "۰۴",
    t: "تسویه و چاپ رسید",
    d: "فاکتور صادر، پرداخت ثبت و رسید فارسی برای بیمار چاپ می‌شود. درآمد به شعبه مربوطه ثبت می‌گردد.",
    icon: "💳",
  },
];

export default function Workflow() {
  return (
    <section id="workflow" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionHead
          badge="جریان کار"
          title={
            <>
              از رزرو تا تسویه، در
              <span className="text-gradient"> یک مسیر پیوسته</span>
            </>
          }
          sub="بدون دفتر کاغذی، بدون اکسل، بدون جابه‌جایی دستی اطلاعات بین بخش‌ها."
        />

        <div className="relative mt-16">
          <div className="absolute inset-x-0 top-16 hidden h-px bg-gradient-to-l from-transparent via-gray-200 to-transparent lg:block" />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map((s, i) => (
              <div
                key={s.n}
                className="reveal group relative"
                style={{ transitionDelay: `${i * 110}ms` }}
              >
                <div className="glass relative h-full overflow-hidden rounded-3xl p-6 transition duration-500 hover:-translate-y-2 hover:shadow-xl">
                  <div className="flex items-center justify-between">
                    <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-emerald-100 to-sky-100 text-2xl transition duration-500 group-hover:rotate-12">
                      {s.icon}
                    </span>
                    <span className="font-mono text-2xl font-black text-gray-100 transition group-hover:text-emerald-200">
                      {s.n}
                    </span>
                  </div>
                  <h3 className="mt-5 text-base font-extrabold text-gray-900">{s.t}</h3>
                  <p className="mt-2 text-[12.5px] leading-7 text-gray-500">{s.d}</p>
                  <span className="absolute inset-x-0 bottom-0 h-0.5 w-0 bg-gradient-to-l from-emerald-400 to-sky-400 transition-all duration-700 group-hover:w-full" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}