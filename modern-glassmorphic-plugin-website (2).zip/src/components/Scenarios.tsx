import { scenarios } from "../data";
import SectionHead from "./SectionHead";

export default function Scenarios() {
  return (
    <section id="scenarios" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionHead
          badge="انعطاف‌پذیری"
          title={
            <>
              مناسب
              <span className="text-gradient"> هر شکل از کسب‌وکار درمانی</span>
            </>
          }
          sub="از یک مطب کوچک تا یک درمانگاه بزرگ با چند شعبه و چند تخصص — سامانه با شما رشد می‌کند."
        />

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {scenarios.map((s, i) => (
            <div
              key={s.title}
              className="reveal glass group relative overflow-hidden rounded-3xl p-6 transition duration-500 hover:-translate-y-1.5 hover:shadow-xl sm:p-7"
              style={{ transitionDelay: `${(i % 2) * 100}ms` }}
            >
              <div className="text-3xl">{s.icon}</div>
              <h3 className="mt-4 text-lg font-extrabold text-gray-900">{s.title}</h3>
              <p className="mt-2.5 text-[13px] leading-7 text-gray-500">{s.desc}</p>
              <div className="pointer-events-none absolute -bottom-20 -left-20 h-48 w-48 rounded-full bg-[radial-gradient(circle_at_center,rgba(110,231,183,0.18),transparent_68%)] transition-opacity duration-500 group-hover:opacity-90" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}