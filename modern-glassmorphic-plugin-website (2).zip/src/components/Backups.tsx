import { backups } from "../data";
import SectionHead from "./SectionHead";

export default function Backups() {
  return (
    <section id="backups" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionHead
          badge="پشتیبان‌گیری"
          title={
            <>
              اطلاعات شما
              <span className="text-gradient"> هرگز از دست نمی‌رود</span>
            </>
          }
          sub="به‌صورت خودکار و منظم از همه اطلاعات نسخه پشتیبان تهیه می‌شود تا با خیال راحت روی کار خود تمرکز کنید."
        />

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {backups.map((b, i) => (
            <div
              key={b.title}
              className="reveal glass-soft group relative rounded-3xl p-6 transition duration-500 hover:-translate-y-2 hover:shadow-lg"
              style={{ transitionDelay: `${(i % 4) * 90}ms` }}
            >
              <div className="flex items-center justify-between">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-emerald-100 to-sky-100 text-2xl transition duration-500 group-hover:rotate-6">
                  {b.icon}
                </span>
                <span className="rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-700">
                  {b.period}
                </span>
              </div>
              <h3 className="mt-5 text-[15px] font-extrabold text-gray-900">{b.title}</h3>
              <p className="mt-2 text-[12.5px] leading-7 text-gray-500">{b.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}