import { useEffect, useRef, useState } from "react";
import SectionHead from "./SectionHead";

const STEP_MS = 3800;

const stations = [
  { icon: "🏠", label: "خانه بیمار", sub: "رزرو آنلاین" },
  { icon: "👩‍💼", label: "پذیرش و منشی", sub: "بررسی نوبت" },
  { icon: "👨‍⚕️", label: "اتاق پزشک", sub: "ویزیت و درمان" },
  { icon: "💳", label: "صندوق", sub: "پرداخت و رسید" },
];

const steps = [
  {
    station: 0,
    badge: "نوبت ثبت شد ✓",
    prop: "📱",
    title: "بیمار از خانه نوبت می‌گیرد",
    desc: "بیمار بدون تماس تلفنی و معطلی، با موبایل خودش پزشک و ساعت دلخواهش را انتخاب می‌کند و نوبتش ثبت می‌شود.",
  },
  {
    station: 0,
    badge: "پیامک رسید 💬",
    prop: "💬",
    title: "پیامک تأیید و یادآوری",
    desc: "تأیید نوبت و یادآوری قبل از ویزیت برای بیمار پیامک می‌شود تا هیچ نوبتی فراموش نشود.",
  },
  {
    station: 1,
    badge: "نوبت تأیید شد ✓",
    prop: "📋",
    title: "منشی نوبت را بررسی می‌کند",
    desc: "بیمار به مطب می‌رسد؛ منشی در چند ثانیه نوبت را تأیید می‌کند و بیمار وارد صف انتظار می‌شود.",
  },
  {
    station: 2,
    badge: "شروع ویزیت 🩺",
    prop: "🩺",
    title: "ملاقات بیمار و پزشک",
    desc: "وقتی نوبت بیمار می‌رسد، پزشک پرونده و سابقه او را روی صفحه می‌بیند و ویزیت شروع می‌شود.",
  },
  {
    station: 2,
    badge: "نسخه صادر شد 💊",
    prop: "💊",
    title: "درمان و صدور نسخه",
    desc: "پزشک تشخیص را ثبت و نسخه را صادر می‌کند. نسخه چاپ می‌شود و بیمار با خیال راحت درمان می‌شود.",
  },
  {
    station: 3,
    badge: "پرداخت شد ✓",
    prop: "🧾",
    title: "پرداخت و دریافت رسید",
    desc: "فاکتور به‌صورت خودکار صادر می‌شود؛ بیمار هزینه را پرداخت می‌کند و رسید چاپی تحویل می‌گیرد.",
  },
  {
    station: 0,
    badge: "سلامت و راضی 🏠",
    prop: "👋",
    title: "بازگشت سالم به خانه",
    desc: "بیمار سالم و راضی به خانه برمی‌گردد و تمام اطلاعات این مراجعه در پرونده‌اش ذخیره شده است.",
  },
];

const fa = (n: number) => n.toLocaleString("fa-IR");

export default function PatientJourney() {
  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [moving, setMoving] = useState(false);
  const prevStation = useRef(0);

  const cur = steps[step];
  const healed = step >= 4;

  // auto advance
  useEffect(() => {
    if (!playing) return;
    const t = setTimeout(() => setStep((s) => (s + 1) % steps.length), STEP_MS);
    return () => clearTimeout(t);
  }, [step, playing]);

  // walking animation when station changes
  useEffect(() => {
    if (prevStation.current !== cur.station) {
      prevStation.current = cur.station;
      setMoving(true);
      const t = setTimeout(() => setMoving(false), 1500);
      return () => clearTimeout(t);
    }
  }, [cur.station]);

  return (
    <section id="story" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <SectionHead
          badge="مسیر یک بیمار"
          title={
            <>
              از خانه تا درمان،
              <span className="text-gradient"> همه چیز را ببینید</span>
            </>
          }
          sub="یک مراجعه کامل را قدم‌به‌قدم دنبال کنید؛ از رزرو نوبت در خانه تا ویزیت، پرداخت و بازگشت."
        />

        <div className="reveal glass relative mt-8 overflow-hidden rounded-[28px] p-4 sm:p-7">
          <div className="pointer-events-none absolute -top-20 -right-16 h-60 w-60 rounded-full bg-[radial-gradient(circle_at_center,rgba(110,231,183,0.32),transparent_66%)]" />
          <div className="pointer-events-none absolute -bottom-24 -left-16 h-60 w-60 rounded-full bg-[radial-gradient(circle_at_center,rgba(125,211,252,0.32),transparent_66%)]" />

          {/* stations */}
          <div className="relative grid grid-cols-4 pt-4">
            {stations.map((s, i) => {
              const active = cur.station === i;
              return (
                <div key={s.label} className="relative px-1 sm:px-2">
                  {active && (
                    <span
                      key={`b-${step}`}
                      className="animate-pop absolute -top-3 left-1/2 z-20 -translate-x-1/2 rounded-full bg-gradient-to-l from-emerald-500 to-sky-500 px-2.5 py-1 text-[9px] font-bold whitespace-nowrap text-white shadow-lg sm:text-[11px]"
                    >
                      {cur.badge}
                    </span>
                  )}
                  <div
                    className={`relative flex flex-col items-center rounded-2xl px-1 py-4 text-center transition-all duration-500 sm:py-6 ${
                      active
                        ? "scale-[1.04] border border-emerald-200 bg-white shadow-xl"
                        : "border border-white/70 bg-white/55 opacity-75"
                    }`}
                  >
                    {active && (
                      <span className="animate-ringping pointer-events-none absolute inset-0 rounded-2xl border-2 border-emerald-300" />
                    )}
                    <span
                      className={`text-3xl transition-transform duration-500 sm:text-5xl ${
                        active ? "animate-floaty" : ""
                      }`}
                      style={{ animationDuration: "2.4s" }}
                    >
                      {s.icon}
                    </span>
                    <span className="mt-2 text-[10px] font-extrabold text-gray-800 sm:text-sm">{s.label}</span>
                    <span className="mt-0.5 text-[9px] text-gray-400 sm:text-[11px]">{s.sub}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* road + patient */}
          <div className="relative mt-3 h-20 sm:h-24">
            <div className="absolute inset-x-[12.5%] bottom-4 border-t-2 border-dashed border-emerald-300/70" />
            {stations.map((_, i) => (
              <span
                key={i}
                className={`absolute bottom-[11px] h-3 w-3 rounded-full border-2 transition-colors duration-500 ${
                  cur.station === i ? "border-emerald-500 bg-emerald-400" : "border-gray-300 bg-white"
                }`}
                style={{ right: `${12.5 + 25 * i}%`, transform: "translateX(50%)" }}
              />
            ))}

            <div
              className="absolute bottom-3 z-10"
              style={{
                right: `${12.5 + 25 * cur.station}%`,
                transform: "translateX(50%)",
                transition: "right 1.4s cubic-bezier(0.65, 0, 0.35, 1)",
              }}
            >
              <div className="relative flex flex-col items-center">
                {/* prop chip */}
                <span
                  key={`p-${step}`}
                  className="animate-pop absolute -top-5 -left-5 grid h-8 w-8 place-items-center rounded-xl border border-gray-100 bg-white text-lg shadow-md sm:-top-6 sm:-left-6 sm:h-9 sm:w-9"
                >
                  {cur.prop}
                </span>

                {/* healing sparkles */}
                {step === 4 && (
                  <>
                    <span className="animate-sparkle absolute -top-2 right-0 text-sm">✨</span>
                    <span className="animate-sparkle absolute -top-1 -left-1 text-sm" style={{ animationDelay: "0.5s" }}>
                      ✨
                    </span>
                    <span className="animate-sparkle absolute top-0 left-4 text-xs" style={{ animationDelay: "0.9s" }}>
                      💚
                    </span>
                  </>
                )}

                <div className={moving ? "animate-bob" : ""}>
                  <div
                    className={`grid h-12 w-12 place-items-center rounded-full border-2 text-3xl shadow-lg transition-colors duration-700 sm:h-14 sm:w-14 sm:text-4xl ${
                      healed ? "border-emerald-300 bg-emerald-50" : "border-amber-200 bg-amber-50"
                    }`}
                  >
                    {healed ? "😊" : "🤒"}
                  </div>
                </div>
                <span className="mt-1 h-1.5 w-8 rounded-full bg-gray-900/10 blur-[2px]" />
              </div>
            </div>
          </div>

          {/* caption */}
          <div className="relative mt-3 rounded-2xl border border-gray-100 bg-white/90 p-4 shadow-sm sm:p-5">
            <div key={step} className="animate-pop flex items-start gap-3 sm:gap-4">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-sky-500 text-sm font-black text-white sm:h-11 sm:w-11">
                {fa(step + 1)}
              </span>
              <div>
                <h3 className="text-[15px] font-extrabold text-gray-900 sm:text-lg">{cur.title}</h3>
                <p className="mt-1 text-[12.5px] leading-7 text-gray-500 sm:text-[13.5px]">{cur.desc}</p>
              </div>
            </div>

            {/* progress + controls */}
            <div className="mt-4 flex items-center gap-3">
              <button
                onClick={() => setPlaying((p) => !p)}
                className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-gray-200 bg-white text-xs text-gray-700 transition hover:bg-gray-50"
                aria-label={playing ? "توقف" : "پخش"}
              >
                {playing ? "❚❚" : "▶"}
              </button>

              <div className="flex flex-1 items-center gap-1.5">
                {steps.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setStep(i)}
                    aria-label={`مرحله ${fa(i + 1)}`}
                    className="group relative h-2 flex-1 overflow-hidden rounded-full bg-gray-200"
                  >
                    {i < step && <span className="absolute inset-0 bg-emerald-400" />}
                    {i === step && (
                      <span
                        key={`${step}-${playing}`}
                        className="absolute inset-y-0 right-0 bg-gradient-to-l from-emerald-400 to-sky-400"
                        style={
                          playing
                            ? { animation: `fillbar ${STEP_MS}ms linear forwards` }
                            : { width: "100%" }
                        }
                      />
                    )}
                  </button>
                ))}
              </div>

              <span className="shrink-0 text-[11px] text-gray-400">
                {fa(step + 1)} از {fa(steps.length)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
