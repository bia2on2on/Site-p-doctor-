export default function Logo({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden>
      <defs>
        <linearGradient id="lgA" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#059669" />
          <stop offset="55%" stopColor="#10b981" />
          <stop offset="100%" stopColor="#1f7df0" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="44" height="44" rx="14" fill="url(#lgA)" opacity="0.12" />
      <rect x="2" y="2" width="44" height="44" rx="14" stroke="url(#lgA)" strokeWidth="1.8" />
      <path
        d="M24 13v22M13 24h22"
        stroke="url(#lgA)"
        strokeWidth="4.2"
        strokeLinecap="round"
      />
      <path
        d="M8 30h7l3-6 4 11 4-14 3 9h11"
        stroke="#ffffff"
        strokeOpacity="0.45"
        strokeWidth="3.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8 30h7l3-6 4 11 4-14 3 9h11"
        stroke="#059669"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}