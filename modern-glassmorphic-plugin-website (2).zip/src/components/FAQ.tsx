import { useState } from "react";
import { faqs } from "../data";
import SectionHead from "./SectionHead";

export default function FAQ() {
  const [open, setOpen] = useState<Set<number>>(new Set([0]));

  const toggle = (i: number) => {
    setOpen((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  };

  return (
    <section id="faq" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-4xl">
        <SectionHead
          badge="سوالات متداول"
          title={
            <>
              هر چه لازم است
              <span className="text-gradient"> بدانید</span>
            </>
          }
        />

        <div className="mt-12 space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open.has(i);
            return (
              <div
                key={f.q}
                className={`reveal overflow-hidden rounded-2xl transition-all duration-500 ${
                  isOpen ? "glass shadow-lg" : "glass-soft"
                }`}
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <button
                  onClick={() => toggle(i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-right"
                >
                  <span className={`text-[14px] font-bold ${isOpen ? "text-gray-900" : "text-gray-600"}`}>
                    {f.q}
                  </span>
                  <span
                    className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg border text-xs transition-transform duration-400 ${
                      isOpen
                        ? "rotate-45 border-emerald-200 bg-emerald-50 text-emerald-600"
                        : "border-gray-200 bg-gray-50 text-gray-400"
                    }`}
                  >
                    +
                  </span>
                </button>
                <div
                  className="grid transition-all duration-500 ease-out"
                  style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-[13px] leading-8 text-gray-500">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}