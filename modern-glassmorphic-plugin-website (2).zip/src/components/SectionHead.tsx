import type { ReactNode } from "react";

export default function SectionHead({
  badge,
  title,
  sub,
  center = true,
}: {
  badge: string;
  title: ReactNode;
  sub?: string;
  center?: boolean;
}) {
  return (
    <div className={`reveal max-w-3xl ${center ? "mx-auto text-center" : ""}`}>
      <span className="glass-soft inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[11px] tracking-wide text-emerald-700">
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
        {badge}
      </span>
      <h2 className="mt-5 text-3xl leading-[1.35] font-black text-gray-900 sm:text-4xl">{title}</h2>
      {sub && <p className="mt-4 text-[14px] leading-8 text-gray-500 sm:text-[15px]">{sub}</p>}
    </div>
  );
}