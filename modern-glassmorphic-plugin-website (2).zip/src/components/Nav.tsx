import { useEffect, useRef, useState } from "react";
import Logo from "./Logo";

const links = [
  { href: "#features", label: "امکانات" },
  { href: "#portals", label: "پنل‌ها" },
  { href: "#workflow", label: "جریان کار" },
  { href: "#scenarios", label: "موارد استفاده" },
  { href: "#faq", label: "سوالات" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const barRef = useRef<HTMLDivElement>(null);

  // Progress bar is written straight to the DOM: scrolling must not re-render React.
  useEffect(() => {
    let ticking = false;
    const update = () => {
      ticking = false;
      const el = document.documentElement;
      setScrolled(el.scrollTop > 24);
      const max = el.scrollHeight - el.clientHeight;
      const p = max > 0 ? Math.min(1, Math.max(0, el.scrollTop / max)) : 0;
      if (barRef.current) barRef.current.style.width = `${p * 100}%`;
    };
    const onScroll = () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(update);
      }
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div
        className={`transition-all duration-500 ${
          scrolled ? "mt-2 px-3 sm:px-5" : "mt-4 px-4 sm:px-8"
        }`}
      >
        <nav
          className={`mx-auto flex max-w-7xl items-center justify-between gap-4 rounded-2xl px-4 py-3 transition-colors duration-500 ${
            scrolled ? "glass shadow-xl" : "glass-soft"
          }`}
        >
          <a href="#top" className="group flex items-center gap-3">
            <span className="transition-transform duration-500 group-hover:rotate-12">
              <Logo size={38} />
            </span>
            <span className="leading-tight">
              <span className="block text-lg font-extrabold tracking-tight text-gray-900">سامانه مطب</span>
              <span className="block text-[11px] text-gray-500">مدیریت هوشمند مطب و درمانگاه</span>
            </span>
          </a>

          <ul className="hidden items-center gap-1 lg:flex">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="rounded-xl px-3.5 py-2 text-sm text-gray-600 transition-colors hover:bg-gray-900/[0.06] hover:text-gray-900"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2">
            <a
              href="#demo"
              className="shrink-0 whitespace-nowrap rounded-xl bg-gradient-to-l from-mint-400 to-azure-500 px-4 py-2 text-sm font-bold text-white shadow-lg shadow-mint-500/25 transition-transform hover:scale-[1.04]"
            >
              درخواست دمو
            </a>
            <button
              onClick={() => setOpen((v) => !v)}
              className="rounded-xl border border-gray-200 bg-white/80 p-2 text-gray-600 lg:hidden"
              aria-label="فهرست"
              aria-expanded={open}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
              </svg>
            </button>
          </div>
        </nav>

        {/* mobile sheet */}
        <div
          className={`mx-auto max-w-7xl overflow-hidden transition-all duration-500 lg:hidden ${
            open ? "mt-2 max-h-96 opacity-100" : "max-h-0 opacity-0"
          }`}
        >
          <ul className="grid grid-cols-2 gap-2 rounded-2xl border border-gray-200 bg-white/95 p-3 shadow-xl">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  onClick={() => setOpen(false)}
                  href={l.href}
                  className="block rounded-xl bg-gray-50 px-4 py-3 text-sm font-medium text-gray-800 transition-colors hover:bg-emerald-50 hover:text-emerald-700"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* scroll progress */}
      <div className="mx-auto mt-2 h-px max-w-7xl overflow-hidden px-6">
        <div
          ref={barRef}
          className="h-px bg-gradient-to-l from-mint-300 via-azure-400 to-violet-400"
          style={{ width: "0%" }}
        />
      </div>
    </header>
  );
}
