import SectionHead from "./SectionHead";

const rows = [
  ["نوبت‌دهی آنلاین ۲۴ ساعته", true, false, true],
  ["صف انتظار لحظه‌ای", true, false, false],
  ["پرونده بیمار و صدور نسخه", true, false, false],
  ["چند مطب و چند شعبه در یک سامانه", true, false, false],
  ["نگهداری اطلاعات روی سرور خودتان", true, true, false],
  ["یکپارچه با سایت فعلی شما", true, false, false],
  ["فارسی، راست‌چین و تاریخ شمسی", true, true, false],
  ["هزینه بر اساس تعداد بیمار", false, false, true],
];

export default function Compare() {
  const cols = ["سامانه ما", "دفتر و رایانه", "سرویس‌های ابری"];

  return (
    <section id="compare" className="relative px-4 py-14 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <SectionHead
          badge="مقایسه"
          title={
            <>
              چرا سامانه ما،
              <span className="text-gradient"> و نه روش‌های قدیمی؟</span>
            </>
          }
        />

        <div className="reveal glass mt-12 overflow-hidden rounded-3xl">
          <div className="grid grid-cols-[1.6fr_repeat(3,0.8fr)] items-center border-b border-gray-100 bg-gray-50 px-4 py-4 text-[11px] sm:px-6 sm:text-[12.5px]">
            <span className="font-bold text-gray-500">قابلیت</span>
            {cols.map((c, i) => (
              <span
                key={c}
                className={`text-center font-extrabold ${i === 0 ? "text-gradient" : "text-gray-400"}`}
              >
                {c}
              </span>
            ))}
          </div>

          {rows.map((r, i) => (
            <div
              key={r[0] as string}
              className="grid grid-cols-[1.6fr_repeat(3,0.8fr)] items-center border-b border-gray-50 px-4 py-3.5 transition hover:bg-gray-50 sm:px-6"
              style={{ transitionDelay: `${i * 40}ms` }}
            >
              <span className="text-[12px] text-gray-600 sm:text-[13px]">{r[0] as string}</span>
              {[1, 2, 3].map((idx) => (
                <span key={idx} className="flex justify-center">
                  {r[idx] ? (
                    <span
                      className={`grid h-6 w-6 place-items-center rounded-lg text-[11px] ${
                        idx === 1
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-gray-100 text-gray-500"
                      }`}
                    >
                      ✓
                    </span>
                  ) : (
                    <span className="grid h-6 w-6 place-items-center rounded-lg bg-gray-50 text-[11px] text-gray-300">
                      ✕
                    </span>
                  )}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}