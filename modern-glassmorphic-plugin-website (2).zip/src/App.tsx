import Background from "./components/Background";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Portals from "./components/Portals";
import Workflow from "./components/Workflow";
import Scenarios from "./components/Scenarios";
import Backups from "./components/Backups";
import Architecture from "./components/Architecture";
import Compare from "./components/Compare";
import PatientJourney from "./components/PatientJourney";
import FAQ from "./components/FAQ";
import DemoCTA from "./components/DemoCTA";
import Footer from "./components/Footer";
import BackToTop from "./components/BackToTop";
import { useReveal } from "./hooks/useReveal";

export default function App() {
  // All sections render on the first paint, so the single IntersectionObserver
  // can find every `.reveal` element in one pass.
  useReveal();

  return (
    <div className="relative flex min-h-screen flex-col">
      <Background />
      <Nav />

      <main className="flex-1">
        <Hero />
        <Features />
        <Portals />
        <Workflow />
        <Scenarios />
        <Backups />
        <Architecture />
        <Compare />
        <PatientJourney />
        <FAQ />
        <DemoCTA />
      </main>

      <Footer />
      <BackToTop />
    </div>
  );
}
